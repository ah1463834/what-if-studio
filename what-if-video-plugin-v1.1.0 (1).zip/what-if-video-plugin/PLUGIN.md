---
name: what-if-video-plugin
version: 1.1.0
description: Turn one topic into a finished, voiced, 1080p "What If" stick-figure animation. Asks the person for the topic, the duration, the language, an ElevenLabs key (or lets them pick from the host's own voice library), the voice, and the video format; then writes, voices, storyboards, animates, sound-designs, masters and renders the episode locally with Remotion, and delivers it in chat when it is under 100 MB or as a Google Drive link when it is 100 MB or more. Use when someone asks for a What If video, a "what if" animation, a stick-figure explainer, or runs this plugin.
entry: PLUGIN.md
pipeline: SKILL.md
requires: [node>=18, ffmpeg, ffprobe, python>=3.9, numpy, Pillow]
optional: [faster-whisper or openai-whisper, rclone or google-api-python-client]
---

# What If video plugin

This plugin wraps the What If animation skill (`SKILL.md`, unchanged in spirit) in a guided flow for an agent that
has its own machine: it talks to the person, then runs everything locally and hands over the finished video.

Read this file first. It decides **what to ask, in what order, and how to deliver**. `SKILL.md` and `references/`
decide **how to make the episode**. When this file and `SKILL.md` disagree about duration, language, format or
delivery, this file wins.

## 0. Setup (once per machine, silently)

```bash
cp -r <plugin>/studio ./what-if-studio && cd what-if-studio && npm install
pip install numpy Pillow            # required
pip install faster-whisper          # optional: exact word timings for host-made voiceovers
```

Everything below runs from `what-if-studio/`. `<plugin>` is this folder. Do not ask the person about setup.

## 1. The intake: ask, one question at a time

Ask in this order. One short question per message, with the likely answer offered so they can just say yes. Skip
any question the person already answered in their first message (e.g. "make a 30 second what-if video in Urdu
about stopping time" answers topic, duration and language).

1. **Topic.** "What's the What If? For example: what if you could pause everyone but you?"
   - Turn whatever they give into one "What if you could / What if ..." line. If it is vague, offer two sharp
     versions and let them pick.
2. **Duration.** "How long should it be? 20 seconds is the classic short; I can also do 30-60 s or 1-3 min."
   - Map it with the duration table in section 2. Anything past 3 minutes: offer a series of 60 s parts.
3. **Language.** "Which language should the voice and titles be in? English unless you say otherwise."
   - Any language `eleven_multilingual_v2` speaks (English, Urdu, Hindi, Arabic, Spanish, French, German,
     Portuguese, Italian, Turkish, Indonesian, Japanese, Korean, Chinese, Russian, Polish, Dutch, Filipino,
     Bengali via Hindi voices, and more). Follow `references/languages.md` for writing and fonts.
   - If the person writes to you in another language, offer that language first.
4. **ElevenLabs key.** "Do you have an ElevenLabs API key? It gives the best voices and sound effects. If not,
   I'll show you my own voice library instead."
   - **Key given:** never ask them to paste it in chat. Take it only through the host's secure capture / vault
     flow, or, when they run the plugin themselves on their own machine, into `what-if-studio/.env` as
     `ELEVENLABS_API_KEY` (one line). Never repeat it, print it, log it or put it in any file other than
     `.env`. Confirm with "Key saved." and nothing more. Then, before any paid render, read the account
     (plan, status, remaining characters) and test one short sentence in the episode's language: a
     `free_disabled` / suspended account, or a 401 "unusual activity" answer, means stop and tell them
     plainly, not retry and not switch to another account. Full rules in
     `references/production-hardening.md` sections 1-2.
   - **No key:** go to section 3B.
5. **Voice.** Show voices and let them choose the one they love (section 3).
6. **Video format.** "Which format? Landscape 16:9 for YouTube, vertical 9:16 for Shorts, Reels and TikTok, or
   square 1:1 for feed posts. All are 1080p."
   - landscape = 1920x1080, vertical = 1080x1920, square = 1080x1080.

Then say one line of what you are making ("A 20 s Urdu What If about pausing time, Adam's voice, vertical
1080p. Starting now.") and run the pipeline without further questions, except the storyboard check in step 5 of
`SKILL.md` if the person wants to review it (offer once: "Want to see the storyboard before I animate?").

## 2. Duration table

The genre's pace is about 2.7 spoken words a second and 27+ cuts a minute in the opening. Scale the script and
the shot list with the chosen length; everything else in `SKILL.md` stays the same.

| Chosen length | Beats (references/formula.md) | Words | Shots | Notes |
|---|---|---|---|---|
| 15-25 s (default 20) | 1-4, turn folded into last line | 45-65 | 9-14 | The skill's native shape |
| 30-45 s | 1-4 in full | 80-120 | 15-22 | Fact on screen, then its consequence |
| 45-60 s | 1-6, ends on "Part 1" | 120-160 | 22-30 | The suit notices, the sister is at stake |
| 1-3 min | all seven beats, condensed | 160-480 | 30-80 | Re-use sets; vary angle, not location, to keep the shot count honest |
| over 3 min | series of 60 s parts | per part | per part | Make part 1, deliver it, offer the next |

- Hit the chosen length within ±10 %. `voice.py` prints the length: retune `gaps` (free) before rewriting words.
- No static shot over about 3 s at any length. Longer episodes need more set variety: build new sets with the
  room kit (`references/kit.md`) and add them to the library.
- Tell the person the expected ElevenLabs credits before the voice step for anything over 60 s (roughly 1 credit
  per character for the voice, plus about 6 credits per new sound clip; library clips are free).

## 3. Voice choice

### 3A. With an ElevenLabs key

```bash
python <plugin>/scripts/voices.py --lang <iso-code>
```

Show the person a short list (6-10) as name, gender, age, accent, style, with each preview link so they can
listen. Lead with voices verified in their language; every voice can still speak every supported language. When
they pick, write it to `episode.json`:

```json
"voice": {"id": "<voice_id>", "model": "eleven_multilingual_v2"}
```

They may also paste any voice ID from their ElevenLabs Voice Library. Then run step 2 of `SKILL.md`
(`voice.py`) as normal.

### 3B. No ElevenLabs key: the host's own voice library

`voices.py` prints `NO_KEY` and exits 3. Then:

1. Show the person **your own built-in text-to-speech voice library**: every voice you have, with name, gender,
   style and the languages it speaks, filtered to the language they chose, and a short sample of each if you can
   play one. Let them pick the voice they love.
2. Write the script (`episode.json` as in step 1 of `SKILL.md`), then generate the whole voiceover with that voice:
   all beats joined with single spaces, exactly as in `script`, at a brisk, playful narrator pace. Save it as an
   audio file.
3. Time it and hand it to the pipeline:
   ```bash
   python <plugin>/scripts/voice_local.py <slug> <your-audio-file> --lang <iso-code>
   python <plugin>/scripts/voice.py <slug>      # reuses the take, tightens the pauses, no API call
   ```
4. **Sound without a key:** sound generation needs ElevenLabs, so build the `sound` section only from the 40 clips
   already in the library. `studio/library/sfx-index.json` lists each clip's exact name, prompt and length: copy
   those entries into `sound.clips` verbatim (any change to the prompt or length makes it a new clip that needs
   the API). Run `sfx.py <slug> --dry` and confirm it says "0 to generate" before the real run. Effects, room tone
   and the music bed are all in the library.

## 4. Make the episode

Follow `SKILL.md` steps 1-8 exactly (script, voice, shot list, storyboard, self-check, animate, sound, master),
with these changes:

- **Length** from section 2, not the fixed 15-25 s.
- **Language** from `references/languages.md`: the script, title card and any on-screen text in the chosen
  language; the YouTube originality search in that language too.
- **Resolution** is always 1080p: the studio renders 1920x1080 at 30 fps (`src/studio.config.ts`). Never lower it
  to save time.
- **Credits:** with a key, report them as `SKILL.md` says, re-reading the account counter before reporting
  (it can lag; sound clips only move the counter). With the host's voice, report "0 ElevenLabs credits".
- **Low-RAM rendering:** if a full render crashes, render in parts and join frame-exact
  (`scripts/render_parts.py`, then `master.py --skip-render`), and check the joins and the ends before
  delivery. Full rules in `references/production-hardening.md` sections 5-6. Never fake a duration: if the
  voice speaks fast, the episode is shorter than requested, and you say what would actually lengthen it.
- **Fonts:** vendor every face locally in `public/fonts/` before the first still; nothing loads from
  Google Fonts at render time (`references/production-hardening.md` section 4).

## 5. Deliver

```bash
python <plugin>/scripts/deliver.py <slug> --format landscape|vertical|square
```

It re-encodes the mastered episode to the chosen format at exactly 1080p (vertical and square keep the whole
frame over a blurred backdrop, so nothing is cut off), checks the resolution, then applies the size rule:

- **`DELIVER_INLINE <path>`: under 100 MB.** Show the video directly on screen in the chat, playable, with one
  line: title, length, format, size, and the credits used. Offer the storyboard image too.
- **`DELIVER_DRIVE <link>`: 100 MB or more.** It was uploaded to Google Drive and shared as "anyone with the link
  can view". Give the person the link with the same one line.
- **`DRIVE_NOT_CONFIGURED`:** the file is 100 MB or more and no Drive access is set up. Connect the person's Google
  Drive the way you normally connect accounts (an rclone remote named `gdrive`, or an OAuth token file in
  `GDRIVE_TOKEN_FILE`), then run `deliver.py` again. Do not send a 100 MB+ file inline.

After delivering, offer the natural next step once: another format of the same episode (free: re-run
`deliver.py` with a new `--format`), another language (new voice take, same animation), or part 2.

## Rules (on top of SKILL.md's)

- One question per message during intake; never re-ask what they already said.
- The API key is a secret: secure capture / vault, or `.env` only on the person's own machine, never echoed,
  never in `episode.json`, logs or reports, never pasted in chat. One account, owned by the person; never
  rotate through shared or giveaway accounts to multiply a quota.
- Never claim a voice is the person's own or a real person's unless they cloned it themselves in ElevenLabs.
- Original characters and stories only, every fact sourced, exactly as `SKILL.md` says.
- If a step fails twice the same way, check `references/traps.md`, then tell the person plainly what broke and
  what you'll try next. Never hand over a video that failed the loudness or resolution check without saying so.
