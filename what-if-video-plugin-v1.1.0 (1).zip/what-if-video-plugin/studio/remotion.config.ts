import { Config } from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg'); // jpeg, not png: png intermediates OOM a low-RAM machine on a full render
Config.setOverwriteOutput(true);
Config.setEntryPoint('src/index.ts');
