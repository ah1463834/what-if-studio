import { loadFont } from '@remotion/fonts';
import { staticFile } from 'remotion';
import { STUDIO } from '../studio.config';

// Three faces: a heavy display face for the title card, a mono for on-screen readouts (timers, labels, chips),
// and a handwriting face for chalk and notes. All files live in public/fonts/ and load offline,
// because the sandbox browser cannot fetch Google Fonts at render time (SSL failure on fonts.gstatic.com),
// while curl through the sandbox proxy can. The files are the official latin subsets from Google Fonts;
// a title face for another script (for example Noto Nastaliq Urdu, also in public/fonts/) loads when
// studio.config.ts sets titleFont. Never load a face from the network at render time.
loadFont({ family: 'Bricolage Grotesque', url: staticFile('fonts/BricolageGrotesque-latin.woff2'), weight: '600' });
loadFont({ family: 'Bricolage Grotesque', url: staticFile('fonts/BricolageGrotesque-latin.woff2'), weight: '700' });
loadFont({ family: 'Bricolage Grotesque', url: staticFile('fonts/BricolageGrotesque-latin.woff2'), weight: '800' });
loadFont({ family: 'Fragment Mono', url: staticFile('fonts/FragmentMono-latin.woff2'), weight: '400' });
loadFont({ family: 'Kalam', url: staticFile('fonts/Kalam-400-latin.woff2'), weight: '400' });
loadFont({ family: 'Kalam', url: staticFile('fonts/Kalam-700-latin.woff2'), weight: '700' });
if (STUDIO.titleFont) loadFont({ family: STUDIO.titleFont.family, url: staticFile(STUDIO.titleFont.file), weight: STUDIO.titleFont.weight });

export const FONT = {
  title: STUDIO.titleFont ? STUDIO.titleFont.family : 'Bricolage Grotesque',
  ui: 'Fragment Mono',
  hand: 'Kalam',
};
