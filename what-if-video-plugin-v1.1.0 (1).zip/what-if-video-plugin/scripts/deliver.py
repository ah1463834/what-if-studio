"""Step 9: deliver. Puts the mastered episode in the format the person chose, at 1080p, then decides how to hand it
over by size.

python <skill>/scripts/deliver.py <slug> --format landscape|vertical|square [--drive-folder <folderId>]

Formats (always 1080p, 30 fps, H.264 High, yuv420p, AAC 256k, faststart):
  landscape  1920x1080  16:9  YouTube, the native frame (no reframing)
  vertical   1080x1920  9:16  Shorts, Reels, TikTok: the 16:9 frame scaled to fill the width, centred, over a
                              blurred, darkened copy of itself (nothing important is cropped off)
  square     1080x1080  1:1   feed posts: same treatment as vertical

Size rule (decided on the delivered file):
  under 100 MB  -> prints  DELIVER_INLINE <path>   : show the video directly in the chat/screen
  100 MB or more -> uploads to Google Drive and prints  DELIVER_DRIVE <link>  : give the person the link
Drive upload tries, in order: rclone (a remote named "gdrive" or $RCLONE_REMOTE), then the Google Drive API with a
service account or OAuth token file in $GOOGLE_APPLICATION_CREDENTIALS / $GDRIVE_TOKEN_FILE. The file is shared
"anyone with the link can view". If neither is set up it prints DRIVE_NOT_CONFIGURED and the host connects Google
Drive the way it normally connects accounts, then re-runs this.
"""
import json, os, pathlib, shutil, subprocess, sys

from wi import load_episode, out_dir, save_json

LIMIT = 100 * 1024 * 1024
slug = sys.argv[1]
args = sys.argv[2:]
fmt = args[args.index('--format') + 1] if '--format' in args else 'landscape'
folder = args[args.index('--drive-folder') + 1] if '--drive-folder' in args else os.environ.get('GDRIVE_FOLDER_ID')
ep = load_episode(slug)
od = out_dir(slug)
final = od / f'{slug}-final.mp4'
if not final.exists():
    raise SystemExit('No final file: run master.py first')

SIZES = {'landscape': (1920, 1080), 'vertical': (1080, 1920), 'square': (1080, 1080)}
if fmt not in SIZES:
    raise SystemExit(f'--format must be one of {list(SIZES)}')
W, H = SIZES[fmt]
out = od / f'{slug}-{fmt}-1080p.mp4'

if fmt == 'landscape':
    vf = f'scale={W}:{H}:flags=lanczos,setsar=1,fps=30'
else:
    vf = (f'split[a][b];[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=30:2,eq=brightness=-0.12[bg];'
          f'[b]scale={W}:-2:flags=lanczos[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,fps=30')


def encode(crf):
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(final), '-filter_complex' if fmt != 'landscape' else '-vf', vf,
                    '-c:v', 'libx264', '-profile:v', 'high', '-pix_fmt', 'yuv420p', '-preset', 'slow', '-crf', str(crf),
                    '-c:a', 'aac', '-b:a', '256k', '-ar', '48000', '-movflags', '+faststart', str(out)], check=True)


encode(18)
size = out.stat().st_size
probe = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height',
                                   '-of', 'json', str(out)], capture_output=True, text=True).stdout)['streams'][0]
assert (probe['width'], probe['height']) == (W, H), f'expected {W}x{H}, got {probe}'
mb = size / 1024 / 1024
print(f'{out.name}: {probe["width"]}x{probe["height"]}, {mb:.1f} MB')


def to_drive(path):
    remote = os.environ.get('RCLONE_REMOTE', 'gdrive')
    if shutil.which('rclone'):
        remotes = subprocess.run(['rclone', 'listremotes'], capture_output=True, text=True).stdout.split()
        if f'{remote}:' in remotes:
            dest = f'{remote}:WhatIf/{slug}/'
            subprocess.run(['rclone', 'copy', str(path), dest], check=True)
            link = subprocess.run(['rclone', 'link', dest + path.name], capture_output=True, text=True).stdout.strip()
            if link:
                return link
    cred = os.environ.get('GDRIVE_TOKEN_FILE') or os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
    if cred and pathlib.Path(cred).exists():
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
        info = json.loads(pathlib.Path(cred).read_text())
        if info.get('type') == 'service_account':
            from google.oauth2 import service_account
            creds = service_account.Credentials.from_service_account_file(cred, scopes=['https://www.googleapis.com/auth/drive.file'])
        else:
            from google.oauth2.credentials import Credentials
            creds = Credentials.from_authorized_user_file(cred, ['https://www.googleapis.com/auth/drive.file'])
        svc = build('drive', 'v3', credentials=creds)
        meta = {'name': path.name, **({'parents': [folder]} if folder else {})}
        f = svc.files().create(body=meta, media_body=MediaFileUpload(str(path), mimetype='video/mp4', resumable=True),
                               fields='id,webViewLink').execute()
        svc.permissions().create(fileId=f['id'], body={'type': 'anyone', 'role': 'reader'}).execute()
        return f['webViewLink']
    return None


report = json.loads((od / 'report.json').read_text()) if (od / 'report.json').exists() else {}
report.update({'delivered': str(out), 'format': fmt, 'resolution': f'{W}x{H}', 'size_mb': round(mb, 1)})

if size < LIMIT:
    report['delivery'] = 'inline'
    save_json(od / 'report.json', report)
    print(f'DELIVER_INLINE {out}')
else:
    link = to_drive(out)
    if not link:
        report['delivery'] = 'drive_pending'
        save_json(od / 'report.json', report)
        print('DRIVE_NOT_CONFIGURED')
        sys.exit(4)
    report['delivery'], report['drive_link'] = 'drive', link
    save_json(od / 'report.json', report)
    print(f'DELIVER_DRIVE {link}')
