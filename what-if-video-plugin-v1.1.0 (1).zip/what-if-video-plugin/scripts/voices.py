"""List voices so the person can pick one they love.

python <skill>/scripts/voices.py [--lang ur] [--json]

With an ElevenLabs key (ELEVENLABS_API_KEY in the environment or a .env above the studio): lists the voices in that
account (premade, cloned and library voices they added), with gender, accent, age, the languages each one has been
verified in, and a preview URL to play before choosing. --lang keeps only voices verified in that language (ISO 639-1,
e.g. en, ur, hi, ar, es, fr, de, pt, tr, id, ja, ko, zh) but every voice can speak every language the model supports
through eleven_multilingual_v2, so the filter is a shortlist, not a limit.

Without a key: prints NO_KEY and exits 3. The host agent then shows its OWN built-in voice library instead
(see PLUGIN.md, "No ElevenLabs key").
"""
import json, os, sys, urllib.request, pathlib

sys.stdout.reconfigure(encoding='utf-8')
args = sys.argv[1:]
lang = args[args.index('--lang') + 1].lower() if '--lang' in args else None
as_json = '--json' in args


def find_key():
    if os.environ.get('ELEVENLABS_API_KEY'):
        return os.environ['ELEVENLABS_API_KEY']
    here = pathlib.Path.cwd()
    for d in [here, *here.parents]:
        p = d / '.env'
        if p.exists():
            raw = p.read_bytes()
            txt = raw.decode('utf-16', 'ignore') if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else raw.decode('utf-8-sig', 'ignore')
            for line in txt.splitlines():
                if line.strip().startswith('ELEVENLABS_API_KEY='):
                    return line.split('=', 1)[1].strip().strip('"').strip("'")
    return None


key = find_key()
if not key:
    print('NO_KEY')
    sys.exit(3)

req = urllib.request.Request('https://api.elevenlabs.io/v2/voices?page_size=100', headers={'xi-api-key': key})
with urllib.request.urlopen(req, timeout=60) as r:
    data = json.loads(r.read())

rows = []
for v in data.get('voices', []):
    lab = v.get('labels') or {}
    langs = sorted({(l.get('language') or '').lower() for l in (v.get('verified_languages') or []) if l.get('language')})
    if lang and langs and lang not in langs:
        continue
    rows.append({
        'voice_id': v['voice_id'], 'name': v.get('name'), 'gender': lab.get('gender', ''), 'age': lab.get('age', ''),
        'accent': lab.get('accent', ''), 'style': lab.get('descriptive') or lab.get('use_case', ''),
        'languages': langs, 'preview_url': v.get('preview_url'),
    })

if as_json:
    print(json.dumps(rows, indent=1, ensure_ascii=False))
else:
    for i, r in enumerate(rows, 1):
        print(f"{i:>2}. {r['name']}  [{r['gender']}, {r['age']}, {r['accent']}, {r['style']}]  langs: {','.join(r['languages']) or 'multilingual'}")
        print(f"    id {r['voice_id']}  preview {r['preview_url']}")
    print(f'{len(rows)} voices' + (f' verified in "{lang}"' if lang else ''))
