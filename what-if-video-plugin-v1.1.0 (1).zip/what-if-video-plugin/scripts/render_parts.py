"""Render in RAM-safe parts, then join frame-exact. Use this when a full render crashes
on a low-RAM machine (Chromium "Page crashed!" / "ran out of memory") instead of
re-running the full render and hoping.

python <skill>/scripts/render_parts.py <slug> [--chunk 300] [--concurrency 1] [--dry]
Runs from the studio folder. Reads src/episodes/<slug>/timeline.json (written by plan.py)
for the total frame count and fps, renders each chunk with Remotion --frames <a>-<b>
(inclusive: chunk 0-300 is 301 frames) at --concurrency 1, concatenates the chunks in
order with ffmpeg stream-copy into out/<slug>/<slug>-raw.mp4, and verifies the joined
frame count equals the timeline total. Then run master.py <slug> --skip-render for the
loudness pass and deliver.py for the chosen format. If one chunk crashes, re-run just
that chunk (or lower --chunk to 200) -- never re-render clean chunks. Set
Config.setVideoImageFormat('jpeg') in remotion.config.ts first: PNG intermediates are
what tip a tight machine over. --dry prints the chunk plan without rendering.
"""
import json, subprocess, sys, pathlib

from wi import STUDIO, ep_dir, load_episode, load_json, out_dir

slug = sys.argv[1]
args = sys.argv[2:]
chunk = int(args[args.index('--chunk') + 1]) if '--chunk' in args else 300
conc = args[args.index('--concurrency') + 1] if '--concurrency' in args else '1'
dry = '--dry' in args
ep = load_episode(slug)
tl = load_json(ep_dir(slug) / 'timeline.json')
if not tl or 'total' not in tl:
    raise SystemExit(f'No timeline.json with a total for {slug}: run plan.py first')
total, fps = int(tl['total']), int(tl.get('fps', 30))
od = out_dir(slug)
raw = od / f'{slug}-raw.mp4'
npx = 'npx.cmd' if sys.platform == 'win32' else 'npx'
cfg = (STUDIO / 'remotion.config.ts').read_text()
if "'png'" in cfg or '"png"' in cfg:
    print('! remotion.config.ts still uses png intermediates; switch to jpeg on a low-RAM machine before rendering')

chunks = []
a = 0
while a < total:
    b = min(a + chunk - 1, total - 1)
    chunks.append((a, b))
    a = b + 1
print(f'{slug}: {total} frames at {fps} fps -> {len(chunks)} chunks of up to {chunk} frames')
parts = []
for a, b in chunks:
    part = od / f'part-{a}-{b}.mp4'
    parts.append(part)
    if dry:
        print(f'  frames {a}-{b} -> {part.name}')
        continue
    if part.exists() and part.stat().st_size > 0:
        print(f'  frames {a}-{b}: {part.name} already rendered, reusing it')
        continue
    print(f'  rendering frames {a}-{b} ...')
    subprocess.run([npx, 'remotion', 'render', 'src/index.ts', ep['id'], str(part),
                    '--frames', f'{a}-{b}', '--concurrency', conc, '--log', 'error'],
                   cwd=STUDIO, check=True)
if dry:
    print('dry run: no rendering done')
    sys.exit(0)

lst = od / 'parts-list.txt'
lst.write_text(''.join(f"file '{p.name}'\n" for p in parts))
subprocess.run(['ffmpeg', '-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', str(lst), '-c', 'copy', str(raw)], check=True)
got = int(subprocess.run(['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
                          '-show_entries', 'stream=nb_read_frames', '-of', 'csv=p=0', str(raw)],
                         capture_output=True, text=True, check=True).stdout.strip())
print(f'joined {raw.name}: {got} frames (timeline total {total}), {raw.stat().st_size / 1024 / 1024:.1f} MB')
if got != total:
    raise SystemExit(f'! frame count mismatch: joined {got}, expected {total} -- do not deliver, find the bad chunk')
print(f'OK: frame-exact join. Next: python <skill>/scripts/master.py {slug} --skip-render')
