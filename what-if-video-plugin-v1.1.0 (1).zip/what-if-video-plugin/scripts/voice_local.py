"""Step 2, no-ElevenLabs path: use a voiceover the HOST made with its own built-in voice library.

python <skill>/scripts/voice_local.py <slug> <audio-file> [--lang ur]

The host agent generates the whole script (all beats joined with spaces, exactly as in episode.json) with the voice
the person picked from its own library, saves it as an audio file (mp3/wav/m4a), then runs this. It:
  1. copies the audio to public/<slug>/voice_raw.mp3
  2. finds word timings: with faster-whisper or openai-whisper if installed (word timestamps, real alignment),
     otherwise by spreading the words over the speech using the silences in the audio (good enough for cutting)
  3. writes out/<slug>/words_raw.json and voice_meta.json with the same signature voice.py uses,
so the normal `python <skill>/scripts/voice.py <slug>` that follows reuses this take (no API call, no key needed)
and tightens the pauses as usual.
"""
import hashlib, json, re, shutil, subprocess, sys, unicodedata

import numpy as np

from wi import decode, load_episode, out_dir, pub_dir, save_json

slug, audio = sys.argv[1], sys.argv[2]
args = sys.argv[3:]
lang = args[args.index('--lang') + 1] if '--lang' in args else None
ep = load_episode(slug)
V = {'id': 'TX3LPaxmHKxFdv7VOQHJ', 'model': 'eleven_multilingual_v2', 'settings': {'stability': 0.4, 'similarity_boost': 0.8, 'style': 0.35, 'use_speaker_boost': True}}
V.update(ep.get('voice', {}))
text = ' '.join(b['text'].strip() for b in ep['script'])
sig = hashlib.sha1(json.dumps([text, V], sort_keys=True).encode()).hexdigest()[:12]

raw_mp3 = pub_dir(slug) / 'voice_raw.mp3'
subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', audio, '-ar', '44100', '-ac', '1', '-b:a', '160k', str(raw_mp3)], check=True)


def is_word_char(ch):
    return bool(re.match(r"[\w'’]", ch)) or unicodedata.category(ch).startswith('M')


def split_words(t):
    """[(word, trailing punctuation)], split the same way voice.py splits ElevenLabs characters."""
    out, cur = [], ''
    for ch in t:
        if is_word_char(ch):
            cur += ch
            continue
        if cur:
            out.append([cur, '']); cur = ''
        if out and ch.strip():
            out[-1][1] += ch
    if cur:
        out.append([cur, ''])
    return [tuple(x) for x in out]


script_words = split_words(text)
words = None

# ---- real alignment if a whisper is installed
try:
    from faster_whisper import WhisperModel
    m = WhisperModel('small', compute_type='int8')
    segs, _ = m.transcribe(str(raw_mp3), language=lang, word_timestamps=True)
    heard = [(w.start, w.end) for s in segs for w in s.words]
except Exception:
    heard = None
    try:
        import whisper
        r = whisper.load_model('small').transcribe(str(raw_mp3), language=lang, word_timestamps=True)
        heard = [(w['start'], w['end']) for s in r['segments'] for w in s['words']]
    except Exception:
        heard = None

if heard and abs(len(heard) - len(script_words)) <= max(2, len(script_words) // 10):
    # map script words onto heard timings by position (the text stays the script's, the clock is the take's)
    n = len(script_words)
    words = []
    for i, (w, p) in enumerate(script_words):
        j = min(len(heard) - 1, round(i * (len(heard) - 1) / max(1, n - 1)))
        s, e = heard[j]
        words.append({'w': w, 's': round(float(s), 3), 'e': round(float(e), 3), 'p': p})
    method = 'whisper'

# ---- fallback: spread words over the voiced stretches, weighted by length
if words is None:
    x = decode(raw_mp3)
    sr = 44100
    hop = int(sr * 0.01)
    env = np.array([np.sqrt(np.mean(x[i:i + hop] ** 2)) for i in range(0, len(x) - hop, hop)])
    thr = max(env.max() * 0.06, np.percentile(env, 20) * 2)
    voiced = env > thr
    t = np.arange(len(env)) * 0.01
    vt = t[voiced]
    if len(vt) == 0:
        raise SystemExit('The audio file is silent.')
    weights = np.array([max(1, len(w)) for w, _ in script_words], float)
    cum = np.concatenate([[0], np.cumsum(weights)]) / weights.sum()
    idx = lambda f: vt[min(len(vt) - 1, int(f * (len(vt) - 1)))]
    words = [{'w': w, 's': round(float(idx(cum[i])), 3), 'e': round(float(idx(cum[i + 1])), 3), 'p': p} for i, (w, p) in enumerate(script_words)]
    method = 'estimated from silences'

save_json(out_dir(slug) / 'words_raw.json', words)
save_json(out_dir(slug) / 'voice_meta.json', {'sig': sig, 'chars': len(text), 'source': 'host voice', 'timing': method})
print(f'{len(words)} words timed ({method}). Now run: python <skill>/scripts/voice.py {slug}')
