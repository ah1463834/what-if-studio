# Making an episode in another language

The engine is language-neutral: the words come from the script, the timing from the voice, the pictures from code.
Four things change.

## 1. Write it natively, don't translate it

- Write the script directly in the target language, following `formula.md`: second person, present tense, three to
  eight words a line, every line a picture, the power's word said on every demo.
- Pick a power word that is short and punchy in that language (Urdu "روکو", Hindi "रुको", Spanish "Pausa",
  Arabic "توقّف"). It is the word the edit cuts on, so it must be one word.
- Word counts in `PLUGIN.md`'s duration table are for English. Languages with longer words (German, Finnish,
  Turkish) use about 15 % fewer words; for Chinese and Japanese count characters: about 4-5 a second.
- The `science` field stays sourced; sources can be in any language.
- Search YouTube in that language for the premise before writing (originality rule in `SKILL.md`).

## 2. The voice

- Model `eleven_multilingual_v2` (the default in `voice.py`) detects the language from the script's text. If a
  voice drifts toward an English accent, pick one verified in the language (`voices.py --lang <iso>`), which
  fixes it in almost every case.
- Numbers: write them as words in the target language so the voice reads them naturally.
- `voice.py` and `voice_local.py` split words on letters plus combining marks, so Devanagari, Arabic-script,
  Thai and Bengali words time correctly. For Chinese and Japanese (no spaces), put a space between the phrases you
  want to cue on, so each phrase becomes one cue word.
- `gaps.pairs` keys use the words as written in the script, e.g. `"روکو|سب": 0.5`.

## 3. Fonts for the title card and on-screen text

The default faces (Bricolage Grotesque, Fragment Mono, Kalam) are Latin only. For any other script, set a local
title font in `src/studio.config.ts` and drop the file in `public/fonts/`:

| Script | Font (Google Fonts, SIL OFL) |
|---|---|
| Arabic, Urdu, Persian | Noto Nastaliq Urdu (Urdu), Noto Kufi Arabic or Cairo (Arabic) |
| Devanagari (Hindi, Marathi, Nepali) | Noto Sans Devanagari, Mukta |
| Bengali | Noto Sans Bengali, Hind Siliguri |
| Cyrillic, Greek, Vietnamese | Bricolage covers some; Noto Sans is safe |
| Chinese / Japanese / Korean | Noto Sans SC / JP / KR |
| Thai | Noto Sans Thai, Kanit |

```ts
titleFont: { family: 'Noto Nastaliq Urdu', file: 'fonts/NotoNastaliqUrdu.woff2', weight: '400 700' },
```

Right-to-left (Arabic, Urdu, Persian, Hebrew): set `direction: 'rtl'` on the title card's text element in the
episode's `index.tsx`, and keep the title to two short lines. Check the title still on the storyboard: a missing
glyph shows as boxes, which fails the self-check.

## 4. Keep the picture wordless

Shots should read without text (formula rule). Any text that must appear in a shot (a phone screen, a sign) goes
in the target language with the same font.
