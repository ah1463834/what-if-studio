# Production hardening

Rules learned the hard way on a real 44-second, 27-shot episode in November 2026, on a
low-RAM machine and with a second ElevenLabs account. They sit on top of `SKILL.md` and
`PLUGIN.md`. When this file and an older rule disagree, this file wins: it is the correction.

## 1. API keys: never in chat, never in a file you hand over

- **Never ask the person to paste an API key in chat, and never accept one pasted there.**
  A key goes in only through the host's secure capture / vault flow, or, when the person
  runs the plugin themselves on their own machine, into that machine's own `.env` as
  `ELEVENLABS_API_KEY`. Never print, repeat, log, or put a key in `episode.json`, a
  report, a cost file, a script, or a chat message. "Key saved." is the whole confirmation.
- **One account, owned by the person.** Never rotate through shared, giveaway, leaked, or
  "another account" logins to multiply a quota. That is terms-of-service evasion, and a
  free account's output cannot be retroactively licensed for a monetised channel. If the
  person offers another key, treat it the same way: secure capture only, then the account
  check in section 2 before any render.
- **The key is by name only in code.** Scripts read `ELEVENLABS_API_KEY` from the
  environment or `.env` (`scripts/wi.py`). Nothing in the plugin ever reads a key out of
  a chat transcript, a report, or a delivered file.

## 2. Before any paid render: check the account, then test one sentence

Do this in order, every time, before the full voice take. A skipped check is how credits
and sessions get burned.

1. **Read the account first.** Plan, status, remaining characters, and whether voice
   cloning is available. Report it in one line, without any secret.
2. **Stop on a disabled account.** If the status is `free_disabled`, suspended, or the
   API answers 401 with "unusual activity" / "upgrade to a paid subscription", stop.
   Do not retry the same call, do not try another tool to get around it, do not switch
   accounts on your own. Tell the person plainly: that account needs an upgrade (or a
   paid account they own) before it can render. No audio, no credits spent, is the
   correct outcome there.
3. **Test one short sentence first** (about 40 characters, in the episode's language,
   with the chosen voice). Check the result is real audio: a non-trivial file size and
   a duration above zero. Only then render the full script, once.
4. **Never re-render the same script.** `voice.py` caches by a hash of text + voice
   settings, so re-running to retune pauses is free. A changed word is a new render;
   budget it before you do it.
5. **Report credits as counter-observed.** The account counter can lag the render by
   minutes, and sound clips only move the counter (they do not appear in the generation
   history). Re-read the counter before you report, and say so if the number may still
   be catching up. Never report a cost you have not read.

## 3. Host voices: test the language, do not assume it

A host's built-in voice library is not a drop-in for ElevenLabs in every language.

- **Test the chosen language with a short sentence first.** A host render can fail
  silently: in the November 2026 run, Urdu host renders returned truncated, empty audio
  (tens of bytes, zero seconds) three times, while an English control with the same
  voice rendered immediately. A failed render is a language block, not a reason to keep
  retrying the same path.
- **If the host test fails, switch paths, not retries.** Go to the ElevenLabs path, or
  to a recording the person supplies themselves. Do not loop the same failing call.
- **Verify by file, not by exit code.** A render counts only when the audio file has
  real size and real duration. A 0-byte or few-dozen-byte file is a failure, however
  cleanly the command exited.
- **Every ElevenLabs voice can speak every supported language** through
  `eleven_multilingual_v2`, but lead with voices verified in the episode's language
  (`voices.py --lang <iso>`); that fixes accent drift in almost every case.

## 4. Fonts: vendor them locally, never fetch at render time

- **Remotion's browser may not be able to fetch Google Fonts** even when the machine's
  network can: in the November 2026 run, Chromium failed on `fonts.gstatic.com` with an
  SSL error through a sandbox proxy, while the same files downloaded fine with curl.
  Every still then failed, for a reason that looked like a drawing bug.
- **Vendor every face before the first still.** The display face, the mono face, the
  handwriting face, and the title face for the episode's script (for example Noto
  Nastaliq Urdu for Urdu) all live in `public/fonts/` as `.woff2` files, and
  `src/engine/fonts.ts` loads them from `staticFile('fonts/...')` with
  `@remotion/fonts`. No face loads from the network at render time.
- **A missing glyph is a font failure, not a script failure.** Boxes on the storyboard
  (especially small labels) mean the font is missing or wrong for that script. Fix the
  font and re-render the still; do not rewrite the script to dodge it.

## 5. Rendering on a low-RAM machine: render in parts, join frame-exact

A full render is not the only way to get a full video, and on a small machine it may
not be a way at all.

- **Symptoms that mean "switch to parts":** Chromium "Page crashed!", "ran out of
  memory", or a render that dies part-way with no output file, on a machine with only
  a few gigabytes free. Do not keep re-running the full render hoping it passes.
- **Settings that make parts fit:** `--concurrency 1`, and `Config.setVideoImageFormat('jpeg')`
  in `remotion.config.ts` (PNG intermediates are what tip a tight machine over; JPEG is
  the shipped default now). A ~300-frame chunk is the proven size on a 7.7 GB machine;
  drop to ~200 frames if a chunk still crashes.
- **The parts workflow** (`scripts/render_parts.py`):
  ```bash
  python <skill>/scripts/render_parts.py <slug> --chunk 300 --concurrency 1
  python <skill>/scripts/master.py <slug> --skip-render
  python <skill>/scripts/deliver.py <slug> --format vertical
  ```
  It renders each chunk with `--frames <a>-<b>` (inclusive, so chunk 0-300 is 301
  frames), concatenates the chunks in order with ffmpeg stream-copy into
  `out/<slug>/<slug>-raw.mp4`, and verifies the frame count against
  `timeline.json`'s total before anything else runs. `master.py --skip-render` then
  does exactly the normal loudness pass (two-pass loudnorm to -14 LUFS, true peak
  under -1 dBTP, video copied untouched) on the joined raw file.
- **If one chunk crashes, re-render only that chunk.** Never re-render clean chunks.
  The join is frame-exact: same settings, same order, no gap, no re-encode of the
  picture. A join lands on a shot cut in practice, so a one-frame hold at a join is
  not visible; a dropped or duplicated frame is a failed join, and the frame-count
  check catches it.
- **The halves are a presentation, not the file.** If the person asked for the video
  in two halves, render in short chunks internally, assemble each half, then join the
  halves into the one full video they asked for. Tell them honestly that the halves
  were rendered in pieces: the delivered file is the joined whole, and its frame
  count is the proof.
- **Storage does not fix a RAM crash.** A machine with plenty of disk and too little
  RAM still crashes the same way, and the finished video is only tens of megabytes.
  Do not ask the person for storage to solve a memory problem.

## 6. Duration, mix, and delivery: report what is real

- **Never fake a duration.** If the voice speaks fast, the episode is shorter than the
  requested length (the November 2026 run: 44.3 s against a 60 s request). Say so, and
  say what would actually lengthen it: a slower delivery or extra lines, not a
  stretched audio track and not padded silence.
- **Mix levels are a decision, not a default.** If `mixcheck.py` flags most of the
  stem crowding the voice, lower the stem levels in `episode.json` and re-run the
  check until only deliberate overlaps remain (a title boom, a turn). In the November
  2026 run that meant sound effects from -1.5 LU to -6.0 LU and music from -9.5 LU
  to -12.0 LU, leaving 18 flagged moments, all deliberate.
- **Check the joins and the ends, not just the middle.** After a parts render, look
  at frames at the start, at each half-join, and at the end, and check the vertical
  reframe does not crop anything important (vertical keeps the whole 16:9 frame over
  a blurred backdrop). Check the loudness and the resolution of the delivered file,
  not just of the raw render.
- **Deliver the format the person chose, and keep the other master.** The vertical
  Shorts file is the delivery when vertical was chosen; the landscape master stays
  in `out/<slug>/` for the other platforms.
